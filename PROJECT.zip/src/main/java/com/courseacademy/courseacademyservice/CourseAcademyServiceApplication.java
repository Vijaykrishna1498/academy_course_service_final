package com.courseacademy.courseacademyservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseAcademyServiceApplication {
    public static void main(String[] args) {

        SpringApplication.run(CourseAcademyServiceApplication.class, args);
        System.out.println("Course Academy Service");
    }
}
