package com.courseacademy.courseacademyservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseAcademyServiceApplicationTests {
    @Test
    void contextLoads() { }
}
