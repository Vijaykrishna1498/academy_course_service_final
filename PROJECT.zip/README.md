# Course Academy Service

Java 21 • Spring Boot 3.3.4 • H2 • JPA • Validation • Swagger UI • DevTools • Jacoco

## Run

```bash
mvn spring-boot:run
# or
mvn clean package && java -jar target/course-academy-service-1.0.0.jar
```

Swagger UI: `http://localhost:8080/swagger-ui.html`  
H2 Console: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:course_academy`, user: `sa`, password empty)

## Entities & Endpoints

- `/api/authors`
- `/api/courses`
- `/api/modules`
- `/api/students`
- `/api/purchases`

All CRUD supported with `ResponseEntity` and validation. No ModelMapper used (manual mappers).
